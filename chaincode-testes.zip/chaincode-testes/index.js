'use strict';
const Chaincode_Contract = require('./chaincode');
module.exports.contracts = [ Chaincode_Contract ];